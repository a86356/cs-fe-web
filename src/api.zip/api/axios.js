import axios from 'axios';
import Base from '@/config/config'
import {getCacheData} from "@/utils/cache";
import BaseConfig from '@/config/config'



import Context from '@/main.js'
axios.defaults.timeout = 5000;
axios.defaults.baseURL =Base.baseURL;

//http request 拦截器
axios.interceptors.request.use(
  config => {
    // const token = getCookie('名称');注意使用的时候需要引入cookie方法，推荐js-cookie
  //  config.data = JSON.stringify(config.data);
    let token = getCacheData(BaseConfig.TOKEN_KEY);

    config.headers = {
      'Content-Type':' application/json',
    }
    if(token){
      config.headers['Authorization']=token
    }

    //  config.params = {'token':'FFE23FD9CD6C7D67C39DD69AE848C8C7F9A51884390C9B9DAA891E23A11DBD396976C48DF92AFBE8D6FC49BE51995B95757AB728453C7FD0DC9AF65A563B392C'}

    return config;
  },
  error => {
    return Promise.reject(error);
  }
);


//http response 拦截器
axios.interceptors.response.use(
  response => {

    //错误处理
    // if(response.data.code=='0'){
    //     return response.data.data;
    // }
    // Modal.info({
    //     title:"提示",
    //     content:response.msg
    // })

    return response;
  },
  error => {
    return Promise.reject(error)
  }
)


export  function  createApi(url,method){



  return  params=> {
    return new Promise((resolve,reject) => {

      if(params.id){
        url=url.replace('{id}',params.id);
      }
    //  delete params.id

      var p;
      if(method=='get' || method=='delete'){
        p={
          params:params
        }
      }


      if(method=='post' || method=='put'){
        p=params
      }

      axios[method](url,p)
        .then(response => {

          if(response.data.code!='0'){
            Context.showmsg('error',response.data.msg);
            reject(response.data);
            return;
          }

          if(response.data.code=='0'){
            if(method=='post' || method=='put'){
              Context.showmsg('success',response.data.msg);

              resolve(response.data);
              return;
            }

          }



          // if(method=='get'){
          //   resolve(response.data);
          // }
          // if(method=='post'){
          //   resolve(response.data);
          // }
          resolve(response.data);
        })
        .catch(err => {
          reject(err)
        })
    })
  }
}
