import {createApi} from './axios';



//账户
export const login = createApi('/api/accounts/login','post');
export const logout = createApi('/api/accounts/logout','post');
export const setPassword4forget = createApi('/api/accounts/setPassword4forget','put');
export const editPassword = createApi('/api/accounts/editPassword','put');
export const getUserInfo = createApi('/api/accounts','get');


//部件

export const batchSelectComponents = createApi('/api/components','post');
export const addComponentLists = createApi('/api/components','post');
export const getComponentLists = createApi('/api/components','get');
export const setComponent = createApi('/api/components/{id}','put');

//用户不写

//公共
export const sendMsg = createApi('/api/commons/sendMsg','post');

//客户身体数据
export const getBodyData = createApi('/api/bodyDatas/{id}','get');
export const getBodyDataList = createApi('/api/bodyDatas','get');
export const addBodyData = createApi('/api/bodyDatas','post');
export const updateBodyData = createApi('/api/bodyDatas/{id}','put');
export const batchDeleteBodyData = createApi('/api/bodyDatas','delete');
export const deleteBodyData = createApi('/api/bodyDatas','delete');

//客户列表
export const batchDeleteCustomerData = createApi('/api/customers','delete');
export const deleteCustomerData = createApi('/api/customers/{id}','delete');
export const addCustomer = createApi('/api/customers','post');
export const getCustomerList = createApi('/api/customers','get');
export const getCustomer = createApi('/api/customers/{id}','get');
export const updateCustomer = createApi('/api/customers/{id}','put');

//品类
export const addCategory = createApi('/api/categories','post');
export const batchAddCategory = createApi('/api/categories','post');
export const updateCategory = createApi('/api/categories/{id}','put');
export const getCategoryList = createApi('/api/categories','get');

//员工
export const getEmployee = createApi('/api/employees/{id}','get');
export const getEmployeeList = createApi('/api/employees','get');
export const addEmployee = createApi('/api/employees','post');
export const updateEmployee = createApi('/api/employees','put');
export const deleteEmployee = createApi('/api/employees/{id}','delete');
export const batchDeleteEmployee = createApi('/api/employees','delete');

//店铺
export const addShop = createApi('/api/shops','post');
export const getShop = createApi('/api/shops/{id}','get');
export const editShop = createApi('/api/shops/{id}','put');
export const getShopList = createApi('/api/shops','get');


//财务
export const getWallets = createApi('/api/wallets','get');
export const getWalletsChangeRecords = createApi('/api/walletChangelRescords','get');


//面料
export const getSystemFabricsList = createApi('/api/systemFabrics','get');
export const batchAddMaterial = createApi('/api/fabrics','post');
export const batchUpdateMaterial = createApi('/api/fabrics','put');
export const updateMaterial = createApi('/api/fabrics/{id}','put');
export const deleteMaterial = createApi('/api/fabrics/{id}','delete');
export const batchDeleteMaterial = createApi('/api/fabrics','delete');
export const addMaterialScan = createApi('/api/fabrics/applyScan','post');











